
#include <stdlib.h>
#include <sys/mman.h>
#include <stdio.h>
#include <assert.h>

#include "hmalloc.h"

/*
typedef struct hm_stats {
  long pages_mapped;
  long pages_unmapped;
  long chunks_allocated;
  long chunks_freed;
  long free_length;
} hm_stats;

typedef struct free_list_node {
    size_t size;
    struct free_list_node* next;
} free_list_node;
*/

const size_t PAGE_SIZE = 4096;
static hm_stats stats; // This initializes the stats to 0.

static free_list_node* free_list_head = NULL;

static void
print_free_list()
{
    int length = 0;
    for (free_list_node* cur = free_list_head; cur != NULL; cur = cur->next)
    {
        ++length;
        printf("%p:\t{ size = %d,\tnext = %p }\n",
                (void*)cur,
                (unsigned int)cur->size,
                (void*)cur->next);
    }
    printf("%d elements\n", length);
}

// gets the length of free_list_head
long
free_list_length()
{
    long length = 0;
    for (free_list_node* node = free_list_head; node != NULL; node = node->next)
    {
        length += 1;
    }
    return length;
}

free_list_node*
free_list_insert_help(free_list_node* node, free_list_node* list)
{
    if (list == NULL)
    {
        node->next = NULL;
        return node;
    }

    if (node < list)
    {
        if ((void*)node + node->size == list)
        {
            // combine before front
            node->size += list->size;
            node->next = list->next;
            return node;
        }

        // add to front, don't combine
        node->next = list;
        return node;
    }

    if ((void*)list + list->size == node)
    {
        // combine after front
        list->size += node->size;
        // have to re-insert this bigger item into the list to deal with
        // possible coalescing
        return free_list_insert_help(list, list->next);
    }

    // don't combine with front, insert into rest
    list->next = free_list_insert_help(node, list->next);
    return list;
}

// Inserts the given block (with a given size field) into the list, and
// combines it with any adjacent blocks.
void
free_list_insert(free_list_node* node)
{
    free_list_head = free_list_insert_help(node, free_list_head);
}

// Searches for the first node with a size of at least min_size, returns it's
// pointer, and removes it from the list (does not free the removed node)
free_list_node*
free_list_remove(size_t min_size)
{
    if (free_list_head == NULL)
    {
        return NULL;
    }

    free_list_node* cur = free_list_head;

    // Head node is big enough
    if (free_list_head->size >= min_size)
    {
        free_list_head = free_list_head->next;
        return cur;
    }

    free_list_node* prev;

    do
    {
        prev = cur;
        cur = cur->next;
    } while (cur != NULL && cur->size < min_size);

    if (cur != NULL)
    {
        prev->next = cur->next;
    }

    return cur;
}

hm_stats*
hgetstats()
{
    stats.free_length = free_list_length();
    return &stats;
}

void
hprintstats()
{
    stats.free_length = free_list_length();
    fprintf(stderr, "\n== husky malloc stats ==\n");
    fprintf(stderr, "Mapped:   %ld\n", stats.pages_mapped);
    fprintf(stderr, "Unmapped: %ld\n", stats.pages_unmapped);
    fprintf(stderr, "Allocs:   %ld\n", stats.chunks_allocated);
    fprintf(stderr, "Frees:    %ld\n", stats.chunks_freed);
    fprintf(stderr, "Freelen:  %ld\n", stats.free_length);
}

static
size_t
div_up(size_t xx, size_t yy)
{
    // This is useful to calculate # of pages
    // for large allocations.
    size_t zz = xx / yy;

    if (zz * yy == xx)
    {
        return zz;
    }
    else
    {
        return zz + 1;
    }
}

void*
hmalloc(size_t size)
{
    stats.chunks_allocated += 1;
    size += sizeof(size_t);

    void* pos;
    size_t block_size;
    
    if (size < PAGE_SIZE)
    {
        // check free list for a big enough block
        free_list_node* node = free_list_remove(size);

        if (node != NULL) // found one
        {
            pos = (void*)node;
            block_size = node->size;
        }
        else // didn't
        {
            // allocate a new page
            block_size = PAGE_SIZE;
            pos = mmap(NULL, block_size, PROT_READ|PROT_WRITE,
                       MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);
            assert(pos != MAP_FAILED);
            stats.pages_mapped += 1;
        }

        if (block_size - size > sizeof(free_list_node))
        {
            // split the block and add the second one to the free list
            free_list_node* new_block = (free_list_node*)(pos + size);
            new_block->size = block_size - size;

            free_list_insert(new_block);

            block_size = size;
        }
    }
    else
    {
        // TODO calculate num pages with pointer arithmetic
        size_t num_pages = div_up(size, PAGE_SIZE);
        block_size = PAGE_SIZE * num_pages;
        pos = mmap(NULL, block_size, PROT_READ|PROT_WRITE,
                         MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);
        assert(pos != MAP_FAILED);
        stats.pages_mapped += num_pages;
    }
    
    *((size_t*)pos) = block_size;
    return pos + sizeof(size_t);
}

void
hfree(void* item)
{
    stats.chunks_freed += 1;

    void* pos = item - sizeof(size_t);
    size_t block_size = *((size_t*)pos);
    
    if (block_size < PAGE_SIZE)
    {
        free_list_insert((free_list_node*)pos);
    }
    else
    {
        assert(munmap(pos, block_size) == 0);
        stats.pages_unmapped += block_size / PAGE_SIZE;
    }
}

